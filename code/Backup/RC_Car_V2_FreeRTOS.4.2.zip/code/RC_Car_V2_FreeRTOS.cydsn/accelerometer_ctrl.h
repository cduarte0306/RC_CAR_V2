/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/

#ifndef ACCELEROMETER_CTRL_H
#define ACCELEROMETER_CTRL_H

#include <cytypes.h>


void accelerometer_setup(void);

#endif

/* [] END OF FILE */
