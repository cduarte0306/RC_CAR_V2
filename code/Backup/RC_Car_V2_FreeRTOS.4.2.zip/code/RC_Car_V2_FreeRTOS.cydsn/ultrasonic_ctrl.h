/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/
#ifndef ULTRASONIC_CTRL_H
#define ULTRASONIC_CTRL_H
    
#include <cytypes.h>
    

void get_distance(int* distance1, int* distance2, int* distance3);
    
#endif
    

/* [] END OF FILE */
